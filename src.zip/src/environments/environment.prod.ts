export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyC4fhh1DS7b7UsNbj2EHNUX86bUilDwXcI",
    authDomain: "notea-6770a.firebaseapp.com",
    projectId: "notea-6770a",
    storageBucket: "notea-6770a.appspot.com",
    messagingSenderId: "322541829527",
    appId: "1:322541829527:web:57c7ecd88a12b97fd7d8d2",
    measurementId: "G-KWNCNPLS91",
    todoCollection:"todo" //coleccion que hacemos coleccion que ponemos aqui 
  }

};
