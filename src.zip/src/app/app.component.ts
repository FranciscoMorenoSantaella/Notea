import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LocalstorageService } from './services/localstorage.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  private langsAviavble = ['es', 'en'];
  constructor(
    private traductor: TranslateService,
    private storage: LocalstorageService
  ) {
    (async () => {
      let lang = await storage.getItem('lang');
      if (lang == null) {
        lang = this.traductor.getBrowserLang();
      }else{
        lang=lang.lang;
      }
      if (this.langsAviavble.indexOf(lang) > -1) {
        traductor.setDefaultLang(lang);
      } else {
        traductor.setDefaultLang('en');
      }
    })();
  }
}
