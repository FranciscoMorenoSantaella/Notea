import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { NoteService } from 'src/app/services/note.service';
import { Note } from 'src/app/model/Note';
import { UtilsService } from 'src/app/services/utils.service';
@Component({
  selector: 'app-modals',
  templateUrl: './modals.page.html',
  styleUrls: ['./modals.page.scss'],
})
export class ModalsPage implements OnInit {
  public notas:Note[]=[];
  private miLoading:HTMLIonLoadingElement;
  constructor(private modalcontroller: ModalController,private ns:NoteService,private load:UtilsService) { }

  ngOnInit() {
  }

  async closeModal(){
    await this.modalcontroller.dismiss();
  }

  public async borrar(nota:Note){
    console.log(nota.key)
    await this.load.presentLoading();
    await this.ns.remove(nota.key);
    let i=this.notas.indexOf(nota,0);
    if(i>-1){
      this.notas.splice(i,1);
    }
    await this.miLoading.dismiss();
    //await this.cargaNotas();
  }

}
