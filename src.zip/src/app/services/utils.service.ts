import { Injectable } from '@angular/core';
import { LoadingController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {
  private miLoading:HTMLIonLoadingElement;
  load: any;
  
  constructor(loading:LoadingController) { }

  async presentLoading(){
    await this.load.create({
      message: ''
    });
    await this.miLoading.present();
  }

}
